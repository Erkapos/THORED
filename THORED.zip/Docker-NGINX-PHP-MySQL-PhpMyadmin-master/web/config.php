<?php
$host = "db";
$username = "root";
$password = "mypass";
$db = "thored_ver_1";

$conn = mysqli_connect($host, $username, $password, $db);
?>
