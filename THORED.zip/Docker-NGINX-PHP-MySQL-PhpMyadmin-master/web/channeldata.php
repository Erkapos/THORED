<?php
include("config.php");

session_start();
      
  


  $cname = $_SESSION['channelName'] = $cnameasdasdasdadsadsa;
?>